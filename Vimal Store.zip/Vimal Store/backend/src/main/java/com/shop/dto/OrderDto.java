package com.shop.dto;

import com.shop.entity.OrderStatus;
import com.shop.entity.PaymentMethod;
import com.shop.entity.PaymentStatus;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

public record OrderDto(
        UUID id,
        String orderNumber,
        OrderStatus orderStatus,
        PaymentMethod paymentMethod,
        PaymentStatus paymentStatus,
        BigDecimal subtotal,
        BigDecimal deliveryFee,
        BigDecimal discount,
        BigDecimal total,
        Instant createdAt,
        List<OrderLineDto> lines,
        AddressDto shippingAddress
) {}
