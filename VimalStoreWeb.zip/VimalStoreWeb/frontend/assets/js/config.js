(function () {
  const params = new URLSearchParams(window.location.search);
  const apiFromQuery = params.get('api');
  window.APP_CONFIG = {
    API_BASE:
      apiFromQuery ||
      window.__API_BASE__ ||
      localStorage.getItem('API_BASE') ||
      'http://localhost:8080',
    GA_ID: window.__GA_ID__ || '',
  };
})();
