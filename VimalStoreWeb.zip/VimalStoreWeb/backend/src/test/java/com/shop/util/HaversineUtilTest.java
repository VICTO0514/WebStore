package com.shop.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class HaversineUtilTest {

    @Test
    void distanceKnownCityPairRoughly() {
        double km = HaversineUtil.distanceKm(13.0827, 80.2707, 13.0475, 80.2496);
        assertTrue(km > 4 && km < 6, "approx distance Chennai spots ~5km");
    }

    @Test
    void samePointZero() {
        assertEquals(0.0, HaversineUtil.distanceKm(10, 77, 10, 77), 0.0001);
    }
}
