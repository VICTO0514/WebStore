package com.shop.service;

import com.shop.dto.ProductDto;
import com.shop.entity.ProductEntity;

public final class ProductMapper {

    private ProductMapper() {}

    public static ProductDto toDto(ProductEntity p) {
        var cat = p.getCategory();
        var effective = p.effectivePrice();
        return new ProductDto(
                p.getId(),
                p.getName(),
                p.getDescription(),
                cat != null ? cat.getId() : null,
                cat != null ? cat.getName() : null,
                cat != null ? cat.getSlug() : null,
                p.getPrice(),
                p.getDiscountedPrice(),
                effective,
                p.getUnit(),
                p.getImageUrl(),
                p.getThumbnailUrl(),
                p.isFeatured(),
                p.getBadge(),
                p.getAvgRating(),
                p.getReviewCount()
        );
    }
}
