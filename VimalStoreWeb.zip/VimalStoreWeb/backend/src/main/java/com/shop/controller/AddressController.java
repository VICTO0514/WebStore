package com.shop.controller;

import com.shop.dto.AddressDto;
import com.shop.service.AddressService;
import com.shop.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/addresses")
@RequiredArgsConstructor
public class AddressController {

    private final AddressService addressService;
    private final AuthService authService;

    @GetMapping
    public ResponseEntity<List<AddressDto.AddressResponse>> list(Authentication authentication) {
        return ResponseEntity.ok(addressService.list(authService.currentUser(authentication)));
    }

    @PostMapping
    public ResponseEntity<AddressDto.AddressResponse> create(
            Authentication authentication,
            @Valid @RequestBody AddressDto.CreateAddressRequest req
    ) {
        return ResponseEntity.ok(addressService.create(authService.currentUser(authentication), req));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(Authentication authentication, @PathVariable UUID id) {
        addressService.delete(authService.currentUser(authentication), id);
        return ResponseEntity.noContent().build();
    }
}
