package com.shop.service;

import com.shop.config.AppProperties;
import com.shop.entity.NotificationEntity;
import com.shop.entity.OrderEntity;
import com.shop.repository.NotificationRepository;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class OwnerNotificationService {

    private final AppProperties appProperties;
    private final NotificationRepository notificationRepository;

    @Transactional
    public void notifyNewOrder(OrderEntity order) {
        String body = buildSmsBody(order);
        String to = appProperties.getOwner().getNotifyPhone();
        NotificationEntity n = NotificationEntity.builder()
                .channel("SMS")
                .recipient(to)
                .subject("New order")
                .body(body)
                .status("PENDING")
                .build();
        notificationRepository.save(n);

        String sid = appProperties.getTwilio().getAccountSid();
        String token = appProperties.getTwilio().getAuthToken();
        if (sid == null || sid.isBlank() || token == null || token.isBlank()) {
            log.warn("Twilio not configured — order notification logged only:\n{}", body);
            n.setStatus("SKIPPED");
            return;
        }
        try {
            Twilio.init(sid, token);
            Message.creator(
                    new PhoneNumber(to),
                    new PhoneNumber(appProperties.getTwilio().getSmsFrom()),
                    body
            ).create();
            n.setStatus("SENT");
        } catch (Exception e) {
            log.error("Twilio send failed", e);
            n.setStatus("FAILED");
        }
    }

    private String buildSmsBody(OrderEntity o) {
        StringBuilder sb = new StringBuilder();
        sb.append("New order ").append(o.getOrderNumber()).append("\n");
        sb.append(o.getCustomer().getFullName()).append(" ").append(o.getCustomer().getPhone()).append("\n");
        sb.append(o.getAddress().getLine1()).append(", ").append(o.getAddress().getCity()).append("\n");
        sb.append("Pay: ").append(o.getPaymentMethod()).append(" Total: ₹").append(o.getTotal()).append("\n");
        o.getItems().forEach(i -> sb.append("- ").append(i.getProductName()).append(" x").append(i.getQuantity()).append("\n"));
        return sb.toString();
    }
}
