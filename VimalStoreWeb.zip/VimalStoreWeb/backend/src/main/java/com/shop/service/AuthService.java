package com.shop.service;

import com.shop.dto.AuthDtos;
import com.shop.entity.RoleName;
import com.shop.entity.UserEntity;
import com.shop.exception.ApiException;
import com.shop.repository.UserRepository;
import com.shop.security.JwtTokenProvider;
import com.shop.security.SecurityUser;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider jwtTokenProvider;
    private final AuthenticationManager authenticationManager;

    @Transactional
    public AuthDtos.AuthResponse register(AuthDtos.RegisterRequest req) {
        if (userRepository.existsByEmail(req.email())) {
            throw new ApiException(HttpStatus.CONFLICT, "Email already registered");
        }
        UserEntity user = UserEntity.builder()
                .email(req.email())
                .passwordHash(passwordEncoder.encode(req.password()))
                .fullName(req.fullName())
                .phone(req.phone())
                .role(RoleName.CUSTOMER)
                .preferredLanguage(req.preferredLanguage() != null ? req.preferredLanguage() : "en")
                .build();
        userRepository.save(user);
        String token = jwtTokenProvider.createToken(user.getId(), user.getEmail(), user.getRole().name());
        return new AuthDtos.AuthResponse(token, user.getEmail(), user.getRole().name(), user.getFullName());
    }

    public AuthDtos.AuthResponse login(AuthDtos.LoginRequest req) {
        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(req.email(), req.password()));
        UserEntity user = userRepository.findByEmail(req.email()).orElseThrow();
        String token = jwtTokenProvider.createToken(user.getId(), user.getEmail(), user.getRole().name());
        return new AuthDtos.AuthResponse(token, user.getEmail(), user.getRole().name(), user.getFullName());
    }

    public SecurityUser currentUser(org.springframework.security.core.Authentication auth) {
        return (SecurityUser) auth.getPrincipal();
    }
}
