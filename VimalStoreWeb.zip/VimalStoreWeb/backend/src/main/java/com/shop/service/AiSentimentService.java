package com.shop.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/** Lightweight sentiment heuristic when Gemini is unavailable. */
@Service
@RequiredArgsConstructor
public class AiSentimentService {

    public String analyze(String text) {
        if (text == null || text.isBlank()) {
            return "neutral";
        }
        String t = text.toLowerCase();
        int pos = count(t, "good", "great", "love", "excellent", "fresh", "best", "nice", "perfect");
        int neg = count(t, "bad", "poor", "worst", "stale", "damaged", "late", "wrong");
        if (pos > neg) {
            return "positive";
        }
        if (neg > pos) {
            return "negative";
        }
        return "neutral";
    }

    private int count(String text, String... words) {
        int n = 0;
        for (String w : words) {
            if (text.contains(w)) {
                n++;
            }
        }
        return n;
    }
}
