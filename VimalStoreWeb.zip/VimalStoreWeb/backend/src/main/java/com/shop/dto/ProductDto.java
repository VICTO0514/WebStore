package com.shop.dto;

import java.math.BigDecimal;
import java.util.UUID;

public record ProductDto(
        UUID id,
        String name,
        String description,
        UUID categoryId,
        String categoryName,
        String categorySlug,
        BigDecimal price,
        BigDecimal discountedPrice,
        BigDecimal effectivePrice,
        String unit,
        String imageUrl,
        String thumbnailUrl,
        boolean featured,
        String badge,
        BigDecimal avgRating,
        int reviewCount
) {}
