package com.shop.service;

import com.shop.dto.AddressDto;
import com.shop.dto.OrderDto;
import com.shop.dto.OrderLineDto;
import com.shop.entity.AddressEntity;
import com.shop.entity.OrderEntity;

import java.util.List;

public final class OrderMapper {

    private OrderMapper() {}

    public static OrderDto toDto(OrderEntity o) {
        List<OrderLineDto> lines = o.getItems().stream()
                .map(i -> new OrderLineDto(
                        i.getProduct().getId(),
                        i.getProductName(),
                        i.getUnitPrice(),
                        i.getQuantity(),
                        i.getLineTotal()
                ))
                .toList();
        AddressEntity a = o.getAddress();
        var addr = new AddressDto.AddressResponse(
                a.getId(),
                a.getLabel(),
                a.getLine1(),
                a.getLine2(),
                a.getCity(),
                a.getState(),
                a.getPostalCode(),
                a.getLatitude(),
                a.getLongitude(),
                a.isDefaultAddress()
        );
        return new OrderDto(
                o.getId(),
                o.getOrderNumber(),
                o.getOrderStatus(),
                o.getPaymentMethod(),
                o.getPaymentStatus(),
                o.getSubtotal(),
                o.getDeliveryFee(),
                o.getDiscount(),
                o.getTotal(),
                o.getCreatedAt(),
                lines,
                addr
        );
    }
}
