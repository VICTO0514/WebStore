package com.shop.dto;

import java.util.UUID;

public record CategoryDto(
        UUID id,
        String name,
        String slug,
        String description,
        String imageUrl,
        String heroImageUrl
) {}
