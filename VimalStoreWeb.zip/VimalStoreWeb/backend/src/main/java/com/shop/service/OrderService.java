package com.shop.service;

import com.shop.dto.CheckoutDtos;
import com.shop.dto.OrderDto;
import com.shop.entity.*;
import com.shop.exception.ApiException;
import com.shop.repository.*;
import com.shop.security.SecurityUser;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final CartRepository cartRepository;
    private final AddressRepository addressRepository;
    private final UserRepository userRepository;
    private final CouponRepository couponRepository;
    private final DeliveryService deliveryService;
    private final OwnerNotificationService ownerNotificationService;
    private final RazorpayPaymentService razorpayPaymentService;
    private final PaymentRepository paymentRepository;

    @Transactional(readOnly = true)
    public CheckoutDtos.CheckoutPreview preview(SecurityUser user, UUID addressId, String couponCode) {
        CartEntity cart = cartRepository.findByUser_Id(user.getId())
                .orElseThrow(() -> new ApiException(HttpStatus.BAD_REQUEST, "Cart is empty"));
        if (cart.getItems().isEmpty()) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Cart is empty");
        }
        AddressEntity address = addressRepository.findById(addressId)
                .filter(a -> a.getUser().getId().equals(user.getId()))
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Address not found"));

        BigDecimal subtotal = computeSubtotal(cart);
        BigDecimal discount = previewDiscount(subtotal, couponCode);
        BigDecimal after = subtotal.subtract(discount).max(BigDecimal.ZERO).setScale(2, RoundingMode.HALF_UP);
        BigDecimal deliveryFee = deliveryService.deliveryFee(after);
        BigDecimal total = after.add(deliveryFee);

        double dist = deliveryService.distanceKm(address.getLatitude(), address.getLongitude());
        boolean eligible = deliveryService.isWithinRadius(address.getLatitude(), address.getLongitude());

        return new CheckoutDtos.CheckoutPreview(subtotal, deliveryFee, discount, total, eligible, dist, couponCode);
    }

    private BigDecimal previewDiscount(BigDecimal subtotal, String couponCode) {
        if (couponCode == null || couponCode.isBlank()) {
            return BigDecimal.ZERO;
        }
        return couponRepository.findByCodeIgnoreCaseAndActiveTrue(couponCode.trim())
                .filter(c -> c.getMinOrderValue() == null || subtotal.compareTo(c.getMinOrderValue()) >= 0)
                .filter(c -> c.getValidUntil() == null || !Instant.now().isAfter(c.getValidUntil()))
                .map(c -> computeDiscount(subtotal, c))
                .orElse(BigDecimal.ZERO);
    }

    @Transactional
    public CheckoutDtos.PlaceOrderResponse placeOrder(SecurityUser user, CheckoutDtos.PlaceOrderRequest req) {
        CartEntity cart = cartRepository.findByUser_Id(user.getId())
                .orElseThrow(() -> new ApiException(HttpStatus.BAD_REQUEST, "Cart is empty"));
        if (cart.getItems().isEmpty()) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Cart is empty");
        }

        AddressEntity address = addressRepository.findById(req.addressId())
                .filter(a -> a.getUser().getId().equals(user.getId()))
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Address not found"));

        if (!deliveryService.isWithinRadius(address.getLatitude(), address.getLongitude())) {
            throw new ApiException(HttpStatus.BAD_REQUEST,
                    "Sorry, delivery is available only within 10 km.");
        }

        UserEntity customer = userRepository.findById(user.getId()).orElseThrow();

        BigDecimal subtotal = computeSubtotal(cart);
        CouponEntity couponEntity = null;
        BigDecimal discount = BigDecimal.ZERO;
        if (req.couponCode() != null && !req.couponCode().isBlank()) {
            CouponEntity c = couponRepository.findByCodeIgnoreCaseAndActiveTrue(req.couponCode().trim())
                    .orElseThrow(() -> new ApiException(HttpStatus.BAD_REQUEST, "Invalid coupon"));
            if (c.getMinOrderValue() != null && subtotal.compareTo(c.getMinOrderValue()) < 0) {
                throw new ApiException(HttpStatus.BAD_REQUEST, "Order value below coupon minimum");
            }
            if (c.getValidUntil() != null && Instant.now().isAfter(c.getValidUntil())) {
                throw new ApiException(HttpStatus.BAD_REQUEST, "Coupon expired");
            }
            couponEntity = c;
            discount = computeDiscount(subtotal, c);
        }

        BigDecimal afterDiscount = subtotal.subtract(discount).max(BigDecimal.ZERO).setScale(2, RoundingMode.HALF_UP);
        BigDecimal deliveryFee = deliveryService.deliveryFee(afterDiscount);
        BigDecimal total = afterDiscount.add(deliveryFee).setScale(2, RoundingMode.HALF_UP);

        PaymentMethod pm;
        try {
            pm = PaymentMethod.valueOf(req.paymentMethod().toUpperCase());
        } catch (Exception e) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Invalid payment method");
        }

        double dist = deliveryService.distanceKm(address.getLatitude(), address.getLongitude());

        OrderEntity order = OrderEntity.builder()
                .orderNumber(generateOrderNumber())
                .customer(customer)
                .address(address)
                .subtotal(subtotal)
                .deliveryFee(deliveryFee)
                .discount(discount)
                .coupon(couponEntity)
                .total(total)
                .paymentMethod(pm)
                .paymentStatus(PaymentStatus.PENDING)
                .orderStatus(OrderStatus.PENDING)
                .distanceKm(BigDecimal.valueOf(dist).setScale(3, RoundingMode.HALF_UP))
                .notes(req.notes())
                .build();

        for (CartItemEntity ci : cart.getItems()) {
            ProductEntity p = ci.getProduct();
            BigDecimal unit = p.effectivePrice();
            BigDecimal line = unit.multiply(BigDecimal.valueOf(ci.getQuantity())).setScale(2, RoundingMode.HALF_UP);
            order.getItems().add(OrderItemEntity.builder()
                    .order(order)
                    .product(p)
                    .productName(p.getName())
                    .unitPrice(unit)
                    .quantity(ci.getQuantity())
                    .lineTotal(line)
                    .build());
        }

        orderRepository.save(order);

        if (couponEntity != null) {
            couponEntity.setUsedCount(couponEntity.getUsedCount() + 1);
            couponRepository.save(couponEntity);
        }

        cart.getItems().clear();
        cartRepository.save(cart);

        String rzOrderId = null;
        String rzKey = null;
        if (pm == PaymentMethod.RAZORPAY) {
            var rz = razorpayPaymentService.createOrder(total, order.getOrderNumber());
            rzOrderId = rz.razorpayOrderId();
            rzKey = rz.keyId();
            order.setRazorpayOrderId(rzOrderId);
            orderRepository.save(order);
        }

        ownerNotificationService.notifyNewOrder(order);

        return new CheckoutDtos.PlaceOrderResponse(
                order.getId(),
                order.getOrderNumber(),
                pm.name(),
                total,
                rzOrderId,
                rzKey
        );
    }

    @Transactional
    public void verifyRazorpay(SecurityUser user, CheckoutDtos.RazorpayVerifyRequest req) {
        OrderEntity order = orderRepository.findByRazorpayOrderId(req.razorpayOrderId())
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Order not found"));
        if (!order.getCustomer().getId().equals(user.getId())) {
            throw new ApiException(HttpStatus.FORBIDDEN, "Forbidden");
        }

        if (!razorpayPaymentService.verifySignature(req.razorpayOrderId(), req.razorpayPaymentId(), req.razorpaySignature())) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Invalid payment signature");
        }

        order.setPaymentStatus(PaymentStatus.PAID);
        order.setOrderStatus(OrderStatus.CONFIRMED);
        order.setRazorpayPaymentId(req.razorpayPaymentId());
        orderRepository.save(order);

        paymentRepository.save(PaymentEntity.builder()
                .order(order)
                .amount(order.getTotal())
                .method("RAZORPAY")
                .status("PAID")
                .razorpayOrderId(req.razorpayOrderId())
                .razorpayPaymentId(req.razorpayPaymentId())
                .razorpaySignature(req.razorpaySignature())
                .build());
    }

    private BigDecimal computeSubtotal(CartEntity cart) {
        BigDecimal subtotal = BigDecimal.ZERO;
        for (CartItemEntity ci : cart.getItems()) {
            BigDecimal unit = ci.getProduct().effectivePrice();
            subtotal = subtotal.add(unit.multiply(BigDecimal.valueOf(ci.getQuantity())));
        }
        return subtotal.setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal computeDiscount(BigDecimal subtotal, CouponEntity c) {
        if ("PERCENT".equalsIgnoreCase(c.getDiscountType())) {
            return subtotal.multiply(c.getDiscountValue()).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
        }
        return c.getDiscountValue().min(subtotal);
    }

    private String generateOrderNumber() {
        return "VS-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    @Transactional(readOnly = true)
    public Page<OrderDto> myOrders(SecurityUser user, int page, int size) {
        return orderRepository.findByCustomer_IdOrderByCreatedAtDesc(user.getId(), PageRequest.of(page, size))
                .map(OrderMapper::toDto);
    }

    @Transactional(readOnly = true)
    public OrderDto getByNumber(SecurityUser user, String orderNumber) {
        OrderEntity o = orderRepository.findByOrderNumber(orderNumber)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Order not found"));
        if (!o.getCustomer().getId().equals(user.getId())) {
            throw new ApiException(HttpStatus.FORBIDDEN, "Forbidden");
        }
        return OrderMapper.toDto(o);
    }
}
