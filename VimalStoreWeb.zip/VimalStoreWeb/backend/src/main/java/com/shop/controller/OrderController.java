package com.shop.controller;

import com.shop.dto.OrderDto;
import com.shop.service.AuthService;
import com.shop.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;
    private final AuthService authService;

    @GetMapping
    public ResponseEntity<Page<OrderDto>> mine(
            Authentication authentication,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        return ResponseEntity.ok(orderService.myOrders(authService.currentUser(authentication), page, size));
    }

    @GetMapping("/{orderNumber}")
    public ResponseEntity<OrderDto> one(Authentication authentication, @PathVariable String orderNumber) {
        return ResponseEntity.ok(orderService.getByNumber(authService.currentUser(authentication), orderNumber));
    }
}
