package com.shop.entity;

public enum PaymentMethod {
    COD,
    RAZORPAY
}
