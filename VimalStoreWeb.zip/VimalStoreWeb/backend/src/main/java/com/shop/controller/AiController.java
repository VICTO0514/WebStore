package com.shop.controller;

import com.shop.dto.ProductDto;
import com.shop.service.AiIntegrationService;
import com.shop.service.AuthService;
import com.shop.service.ChatSessionService;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/ai")
@RequiredArgsConstructor
public class AiController {

    private final AiIntegrationService aiIntegrationService;
    private final ChatSessionService chatSessionService;
    private final AuthService authService;

    @GetMapping("/nl-search")
    public ResponseEntity<List<ProductDto>> nlSearch(@RequestParam @NotBlank String q) {
        return ResponseEntity.ok(aiIntegrationService.naturalLanguageSearch(q));
    }

    @PostMapping("/chat")
    public ResponseEntity<Map<String, String>> chat(
            Authentication authentication,
            @RequestBody Map<String, String> body
    ) {
        String sessionId = body.getOrDefault("sessionId", UUID.randomUUID().toString());
        String message = body.get("message");
        String reply = chatSessionService.reply(authService.currentUser(authentication), sessionId, message);
        return ResponseEntity.ok(Map.of("reply", reply, "sessionId", sessionId));
    }

    @PostMapping("/chat/guest")
    public ResponseEntity<Map<String, String>> chatGuest(@RequestBody Map<String, String> body) {
        String sessionId = body.getOrDefault("sessionId", UUID.randomUUID().toString());
        String message = body.get("message");
        String reply = chatSessionService.anonymousReply(sessionId, message);
        return ResponseEntity.ok(Map.of("reply", reply, "sessionId", sessionId));
    }

    @GetMapping("/recommend/fbt/{productId}")
    public ResponseEntity<List<ProductDto>> fbt(@PathVariable UUID productId) {
        return ResponseEntity.ok(aiIntegrationService.frequentlyBoughtTogether(productId));
    }

    @PostMapping("/recommend/personalized")
    public ResponseEntity<List<ProductDto>> personalized(@RequestBody Map<String, List<UUID>> body) {
        List<UUID> ids = body.getOrDefault("productIds", List.of());
        return ResponseEntity.ok(aiIntegrationService.personalized(ids));
    }
}
