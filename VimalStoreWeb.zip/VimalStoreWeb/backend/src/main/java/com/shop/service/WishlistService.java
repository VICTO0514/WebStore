package com.shop.service;

import com.shop.dto.ProductDto;
import com.shop.entity.ProductEntity;
import com.shop.entity.UserEntity;
import com.shop.entity.WishlistEntity;
import com.shop.exception.ApiException;
import com.shop.repository.ProductRepository;
import com.shop.repository.UserRepository;
import com.shop.repository.WishlistRepository;
import com.shop.security.SecurityUser;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class WishlistService {

    private final WishlistRepository wishlistRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;

    @Transactional(readOnly = true)
    public List<ProductDto> list(SecurityUser user) {
        return wishlistRepository.findByUser_Id(user.getId()).stream()
                .map(WishlistEntity::getProduct)
                .map(ProductMapper::toDto)
                .toList();
    }

    @Transactional
    public void add(SecurityUser user, UUID productId) {
        ProductEntity p = productRepository.findById(productId).filter(ProductEntity::isActive)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Product not found"));
        UserEntity u = userRepository.findById(user.getId()).orElseThrow();
        if (wishlistRepository.findByUser_IdAndProduct_Id(user.getId(), productId).isEmpty()) {
            wishlistRepository.save(WishlistEntity.builder().user(u).product(p).build());
        }
    }

    @Transactional
    public void remove(SecurityUser user, UUID productId) {
        wishlistRepository.deleteByUser_IdAndProduct_Id(user.getId(), productId);
    }
}
