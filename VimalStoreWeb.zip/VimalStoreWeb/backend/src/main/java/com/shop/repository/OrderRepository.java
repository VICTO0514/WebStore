package com.shop.repository;

import com.shop.entity.OrderEntity;
import com.shop.entity.OrderStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface OrderRepository extends JpaRepository<OrderEntity, UUID> {
    Optional<OrderEntity> findByOrderNumber(String orderNumber);

    Optional<OrderEntity> findByRazorpayOrderId(String razorpayOrderId);

    Page<OrderEntity> findByCustomer_IdOrderByCreatedAtDesc(UUID customerId, Pageable pageable);

    Page<OrderEntity> findAllByOrderByCreatedAtDesc(Pageable pageable);

    List<OrderEntity> findTop5ByCustomer_IdOrderByCreatedAtDesc(UUID customerId);

    long countByOrderStatus(OrderStatus status);
}
