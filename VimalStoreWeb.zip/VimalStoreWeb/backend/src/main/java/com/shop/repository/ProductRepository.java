package com.shop.repository;

import com.shop.entity.ProductEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.UUID;

public interface ProductRepository extends JpaRepository<ProductEntity, UUID> {
    Page<ProductEntity> findByActiveTrueAndCategoryId(UUID categoryId, Pageable pageable);

    Page<ProductEntity> findByActiveTrue(Pageable pageable);

    @Query("""
            SELECT p FROM ProductEntity p JOIN p.category c
            WHERE p.active = true AND (:cat IS NULL OR c.slug = :cat)
            AND (
              lower(p.name) LIKE lower(concat('%', :q, '%'))
              OR lower(coalesce(p.description, '')) LIKE lower(concat('%', :q, '%'))
            )
            """)
    Page<ProductEntity> searchActive(@Param("q") String q, @Param("cat") String cat, Pageable pageable);

    @Query("SELECT p FROM ProductEntity p JOIN FETCH p.category WHERE p.id = :id AND p.active = true")
    java.util.Optional<ProductEntity> findActiveWithCategory(@Param("id") UUID id);

    Page<ProductEntity> findByActiveTrueAndFeaturedTrue(Pageable pageable);
}
