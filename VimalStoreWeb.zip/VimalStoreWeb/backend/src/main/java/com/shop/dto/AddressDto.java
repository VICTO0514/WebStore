package com.shop.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.UUID;

public class AddressDto {

    public record AddressResponse(
            UUID id,
            String label,
            String line1,
            String line2,
            String city,
            String state,
            String postalCode,
            double latitude,
            double longitude,
            boolean defaultAddress
    ) {}

    public record CreateAddressRequest(
            String label,
            @NotBlank String line1,
            String line2,
            @NotBlank String city,
            String state,
            String postalCode,
            @NotNull Double latitude,
            @NotNull Double longitude,
            boolean defaultAddress
    ) {}
}
