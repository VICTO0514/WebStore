package com.shop.controller;

import com.shop.dto.ProductDto;
import com.shop.service.AuthService;
import com.shop.service.WishlistService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/wishlist")
@RequiredArgsConstructor
public class WishlistController {

    private final WishlistService wishlistService;
    private final AuthService authService;

    @GetMapping
    public ResponseEntity<List<ProductDto>> list(Authentication authentication) {
        return ResponseEntity.ok(wishlistService.list(authService.currentUser(authentication)));
    }

    @PostMapping("/{productId}")
    public ResponseEntity<Void> add(Authentication authentication, @PathVariable UUID productId) {
        wishlistService.add(authService.currentUser(authentication), productId);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{productId}")
    public ResponseEntity<Void> remove(Authentication authentication, @PathVariable UUID productId) {
        wishlistService.remove(authService.currentUser(authentication), productId);
        return ResponseEntity.noContent().build();
    }
}
