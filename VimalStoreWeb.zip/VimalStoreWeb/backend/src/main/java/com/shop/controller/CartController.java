package com.shop.controller;

import com.shop.dto.CartDtos;
import com.shop.service.AuthService;
import com.shop.service.CartService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/cart")
@RequiredArgsConstructor
public class CartController {

    private final CartService cartService;
    private final AuthService authService;

    @GetMapping
    public ResponseEntity<CartDtos.CartResponse> get(Authentication authentication) {
        return ResponseEntity.ok(cartService.get(authService.currentUser(authentication)));
    }

    @PostMapping("/items")
    public ResponseEntity<CartDtos.CartResponse> add(
            Authentication authentication,
            @Valid @RequestBody CartDtos.AddItemRequest req
    ) {
        return ResponseEntity.ok(cartService.addItem(authService.currentUser(authentication), req));
    }

    @PatchMapping("/items/{itemId}")
    public ResponseEntity<CartDtos.CartResponse> update(
            Authentication authentication,
            @PathVariable UUID itemId,
            @Valid @RequestBody CartDtos.UpdateItemRequest req
    ) {
        return ResponseEntity.ok(cartService.updateQuantity(authService.currentUser(authentication), itemId, req));
    }

    @DeleteMapping("/items/{itemId}")
    public ResponseEntity<CartDtos.CartResponse> remove(Authentication authentication, @PathVariable UUID itemId) {
        return ResponseEntity.ok(cartService.remove(authService.currentUser(authentication), itemId));
    }
}
