package com.shop.service;

import com.shop.dto.AddressDto;
import com.shop.entity.AddressEntity;
import com.shop.entity.UserEntity;
import com.shop.exception.ApiException;
import com.shop.repository.AddressRepository;
import com.shop.repository.UserRepository;
import com.shop.security.SecurityUser;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AddressService {

    private final AddressRepository addressRepository;
    private final UserRepository userRepository;

    @Transactional(readOnly = true)
    public List<AddressDto.AddressResponse> list(SecurityUser user) {
        return addressRepository.findByUser_IdOrderByCreatedAtDesc(user.getId()).stream()
                .map(this::toDto)
                .toList();
    }

    @Transactional
    public AddressDto.AddressResponse create(SecurityUser user, AddressDto.CreateAddressRequest req) {
        UserEntity u = userRepository.findById(user.getId()).orElseThrow();
        if (req.defaultAddress()) {
            addressRepository.findByUser_IdOrderByCreatedAtDesc(user.getId()).forEach(a -> {
                a.setDefaultAddress(false);
                addressRepository.save(a);
            });
        }
        AddressEntity a = AddressEntity.builder()
                .user(u)
                .label(req.label())
                .line1(req.line1())
                .line2(req.line2())
                .city(req.city())
                .state(req.state())
                .postalCode(req.postalCode())
                .latitude(req.latitude())
                .longitude(req.longitude())
                .defaultAddress(req.defaultAddress())
                .build();
        return toDto(addressRepository.save(a));
    }

    @Transactional
    public void delete(SecurityUser user, UUID id) {
        AddressEntity a = addressRepository.findById(id)
                .filter(x -> x.getUser().getId().equals(user.getId()))
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Address not found"));
        addressRepository.delete(a);
    }

    private AddressDto.AddressResponse toDto(AddressEntity a) {
        return new AddressDto.AddressResponse(
                a.getId(),
                a.getLabel(),
                a.getLine1(),
                a.getLine2(),
                a.getCity(),
                a.getState(),
                a.getPostalCode(),
                a.getLatitude(),
                a.getLongitude(),
                a.isDefaultAddress()
        );
    }
}
