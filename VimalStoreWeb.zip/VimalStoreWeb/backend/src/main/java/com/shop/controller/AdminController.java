package com.shop.controller;

import com.shop.dto.OrderDto;
import com.shop.dto.ProductDto;
import com.shop.entity.OrderStatus;
import com.shop.service.AdminService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/admin")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class AdminController {

    private final AdminService adminService;

    @GetMapping("/dashboard")
    public ResponseEntity<Map<String, Object>> dashboard() {
        return ResponseEntity.ok(adminService.dashboard());
    }

    @GetMapping("/orders")
    public ResponseEntity<Page<OrderDto>> orders(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size
    ) {
        return ResponseEntity.ok(adminService.allOrders(page, size));
    }

    @PatchMapping("/orders/{orderNumber}/status")
    public ResponseEntity<Void> orderStatus(
            @PathVariable String orderNumber,
            @RequestParam OrderStatus status
    ) {
        adminService.updateOrderStatus(orderNumber, status);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/products")
    public ResponseEntity<ProductDto> createProduct(@Valid @RequestBody AdminService.ProductUpsert req) {
        return ResponseEntity.ok(adminService.createProduct(req));
    }

    @PutMapping("/products/{id}")
    public ResponseEntity<ProductDto> updateProduct(
            @PathVariable UUID id,
            @Valid @RequestBody AdminService.ProductUpsert req
    ) {
        return ResponseEntity.ok(adminService.updateProduct(id, req));
    }

    @PatchMapping("/reviews/{id}/visibility")
    public ResponseEntity<Void> reviewVisibility(
            @PathVariable UUID id,
            @RequestParam boolean visible
    ) {
        adminService.setReviewVisibility(id, visible);
        return ResponseEntity.ok().build();
    }
}
