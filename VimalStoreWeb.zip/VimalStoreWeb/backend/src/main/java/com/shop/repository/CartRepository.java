package com.shop.repository;

import com.shop.entity.CartEntity;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface CartRepository extends JpaRepository<CartEntity, UUID> {
    @EntityGraph(attributePaths = {"items", "items.product", "items.product.category"})
    Optional<CartEntity> findByUser_Id(UUID userId);
}
