package com.shop.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;

@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "app")
public class AppProperties {
    private Jwt jwt = new Jwt();
    private Shop shop = new Shop();
    private Delivery delivery = new Delivery();
    private Cors cors = new Cors();
    private Gemini gemini = new Gemini();
    private OpenAi openai = new OpenAi();
    private Razorpay razorpay = new Razorpay();
    private Twilio twilio = new Twilio();
    private Owner owner = new Owner();
    private RateLimit rateLimit = new RateLimit();

    @Getter
    @Setter
    public static class Jwt {
        private String secret;
        private long expirationMs;
    }

    @Getter
    @Setter
    public static class Shop {
        private String name;
        private String phone;
        private String email;
        private String address;
        private double latitude;
        private double longitude;
    }

    @Getter
    @Setter
    public static class Delivery {
        private double radiusKm;
    }

    @Getter
    @Setter
    public static class Cors {
        private List<String> allowedOrigins;
    }

    @Getter
    @Setter
    public static class Gemini {
        private String apiKey;
        private String model;
    }

    @Getter
    @Setter
    public static class OpenAi {
        private String apiKey;
        private String model;
    }

    @Getter
    @Setter
    public static class Razorpay {
        private String keyId;
        private String keySecret;
    }

    @Getter
    @Setter
    public static class Twilio {
        private String accountSid;
        private String authToken;
        private String whatsappFrom;
        private String smsFrom;
    }

    @Getter
    @Setter
    public static class Owner {
        private String notifyPhone;
    }

    @Getter
    @Setter
    public static class RateLimit {
        private int requestsPerMinute = 120;
    }
}
