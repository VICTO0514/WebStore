package com.shop.entity;

public enum PaymentStatus {
    PENDING,
    PAID,
    FAILED,
    REFUNDED
}
