package com.shop.service;

import com.shop.dto.CartDtos;
import com.shop.dto.ProductDto;
import com.shop.entity.CartEntity;
import com.shop.entity.CartItemEntity;
import com.shop.entity.ProductEntity;
import com.shop.entity.UserEntity;
import com.shop.exception.ApiException;
import com.shop.repository.CartRepository;
import com.shop.repository.ProductRepository;
import com.shop.repository.UserRepository;
import com.shop.security.SecurityUser;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class CartService {

    private final CartRepository cartRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;

    @Transactional(readOnly = true)
    public CartDtos.CartResponse get(SecurityUser user) {
        CartEntity cart = cartRepository.findByUser_Id(user.getId()).orElse(null);
        if (cart == null || cart.getItems().isEmpty()) {
            return new CartDtos.CartResponse(java.util.List.of(), BigDecimal.ZERO);
        }
        BigDecimal subtotal = BigDecimal.ZERO;
        var lines = new ArrayList<CartDtos.CartItemDto>();
        for (CartItemEntity item : cart.getItems()) {
            ProductEntity p = item.getProduct();
            BigDecimal unit = p.effectivePrice();
            BigDecimal line = unit.multiply(BigDecimal.valueOf(item.getQuantity())).setScale(2, RoundingMode.HALF_UP);
            subtotal = subtotal.add(line);
            ProductDto dto = ProductMapper.toDto(p);
            lines.add(new CartDtos.CartItemDto(item.getId(), dto, item.getQuantity(), line));
        }
        return new CartDtos.CartResponse(lines, subtotal);
    }

    @Transactional
    public CartDtos.CartResponse addItem(SecurityUser user, CartDtos.AddItemRequest req) {
        ProductEntity product = productRepository.findById(req.productId())
                .filter(ProductEntity::isActive)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Product not found"));
        UserEntity owner = userRepository.findById(user.getId()).orElseThrow();
        CartEntity cart = cartRepository.findByUser_Id(user.getId())
                .orElseGet(() -> cartRepository.save(CartEntity.builder().user(owner).build()));
        CartItemEntity existing = cart.getItems().stream()
                .filter(i -> i.getProduct().getId().equals(product.getId()))
                .findFirst()
                .orElse(null);
        if (existing != null) {
            existing.setQuantity(existing.getQuantity() + req.quantity());
        } else {
            cart.getItems().add(CartItemEntity.builder().cart(cart).product(product).quantity(req.quantity()).build());
        }
        cartRepository.save(cart);
        return get(user);
    }

    @Transactional
    public CartDtos.CartResponse updateQuantity(SecurityUser user, UUID itemId, CartDtos.UpdateItemRequest req) {
        CartEntity cart = cartRepository.findByUser_Id(user.getId())
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Cart empty"));
        CartItemEntity item = cart.getItems().stream()
                .filter(i -> i.getId().equals(itemId))
                .findFirst()
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Line not found"));
        item.setQuantity(req.quantity());
        cartRepository.save(cart);
        return get(user);
    }

    @Transactional
    public CartDtos.CartResponse remove(SecurityUser user, UUID itemId) {
        CartEntity cart = cartRepository.findByUser_Id(user.getId())
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Cart empty"));
        cart.getItems().removeIf(i -> i.getId().equals(itemId));
        cartRepository.save(cart);
        return get(user);
    }

    @Transactional
    public void clear(SecurityUser user) {
        cartRepository.findByUser_Id(user.getId()).ifPresent(c -> {
            c.getItems().clear();
            cartRepository.save(c);
        });
    }
}
