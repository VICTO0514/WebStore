package com.shop.repository;

import com.shop.entity.AddressEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface AddressRepository extends JpaRepository<AddressEntity, UUID> {
    List<AddressEntity> findByUser_IdOrderByCreatedAtDesc(UUID userId);
}
