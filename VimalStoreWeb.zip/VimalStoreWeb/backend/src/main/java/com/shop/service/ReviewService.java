package com.shop.service;

import com.shop.dto.ReviewDtos;
import com.shop.entity.ProductEntity;
import com.shop.entity.ReviewEntity;
import com.shop.entity.UserEntity;
import com.shop.exception.ApiException;
import com.shop.repository.ProductRepository;
import com.shop.repository.ReviewRepository;
import com.shop.repository.UserRepository;
import com.shop.security.SecurityUser;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ReviewService {

    private final ReviewRepository reviewRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;
    private final AiSentimentService sentimentService;

    @Transactional(readOnly = true)
    public Page<ReviewDtos.ReviewResponse> forProduct(UUID productId, int page, int size) {
        return reviewRepository.findByProduct_IdAndVisibleTrueOrderByCreatedAtDesc(productId, PageRequest.of(page, size))
                .map(r -> new ReviewDtos.ReviewResponse(
                        r.getId(),
                        r.getRating(),
                        r.getTitle(),
                        r.getComment(),
                        maskName(r.getUser().getFullName()),
                        r.getCreatedAt()
                ));
    }

    @Transactional
    public ReviewDtos.ReviewResponse create(SecurityUser user, ReviewDtos.CreateReviewRequest req) {
        ProductEntity p = productRepository.findById(req.productId()).filter(ProductEntity::isActive)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Product not found"));
        if (reviewRepository.findByProduct_IdAndUser_Id(req.productId(), user.getId()).isPresent()) {
            throw new ApiException(HttpStatus.CONFLICT, "Already reviewed this product");
        }
        UserEntity u = userRepository.findById(user.getId()).orElseThrow();
        String sentiment = sentimentService.analyze(req.comment());
        ReviewEntity r = ReviewEntity.builder()
                .product(p)
                .user(u)
                .rating(req.rating())
                .title(req.title())
                .comment(req.comment())
                .sentiment(sentiment)
                .moderated(false)
                .visible(true)
                .build();
        reviewRepository.save(r);
        return new ReviewDtos.ReviewResponse(r.getId(), r.getRating(), r.getTitle(), r.getComment(), maskName(u.getFullName()), r.getCreatedAt());
    }

    private String maskName(String fullName) {
        if (fullName == null || fullName.isBlank()) {
            return "Customer";
        }
        String[] parts = fullName.trim().split("\\s+");
        return parts[0].charAt(0) + "***";
    }
}
