package com.shop.service;

import com.shop.config.AppProperties;
import com.shop.dto.ProductDto;
import com.shop.repository.ProductRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class AiIntegrationService {

    private final AppProperties appProperties;
    private final ProductRepository productRepository;
    private final ObjectMapper objectMapper;

    private static final HttpClient HTTP = HttpClient.newHttpClient();

    @Transactional(readOnly = true)
    public List<ProductDto> naturalLanguageSearch(String query) {
        if (query == null || query.isBlank()) {
            return List.of();
        }
        String q = query.trim();
        String augmented = maybeRewriteQuery(q);
        return productRepository.searchActive(augmented, null, PageRequest.of(0, 24))
                .map(ProductMapper::toDto)
                .getContent();
    }

    private String maybeRewriteQuery(String userQuery) {
        String key = appProperties.getGemini().getApiKey();
        if (key == null || key.isBlank()) {
            return userQuery;
        }
        try {
            String prompt = """
                    Convert this grocery shopping request into a short English keyword phrase for catalog search.
                    Examples: "breakfast items" -> "rice atta cornflakes milk"; "soap under 50 rupees" -> "soap"; "milk and curd" -> "milk curd".
                    Reply with ONLY the keywords, max 12 words.
                    Request: %s
                    """.formatted(userQuery);
            String body = geminiGenerate(prompt);
            return body != null && !body.isBlank() ? body : userQuery;
        } catch (Exception e) {
            log.warn("Gemini rewrite failed: {}", e.getMessage());
            return userQuery;
        }
    }

    public String chatReply(String userMessage, List<String> historyTail) {
        String key = appProperties.getGemini().getApiKey();
        if (key == null || key.isBlank()) {
            return "Thanks for reaching out! Call us at " + appProperties.getShop().getPhone()
                    + ". (Set GEMINI_API_KEY for AI assistant.)";
        }
        try {
            StringBuilder ctx = new StringBuilder();
            historyTail.forEach(line -> ctx.append(line).append("\n"));
            String prompt = """
                    You are a grocery store assistant for %s in India. Be brief and helpful.
                    Delivery within %s km only. Mention Tamil/English OK.
                    Context:
                    %s
                    User: %s
                    Assistant:
                    """.formatted(
                    appProperties.getShop().getName(),
                    appProperties.getDelivery().getRadiusKm(),
                    ctx,
                    userMessage
            );
            return geminiGenerate(prompt);
        } catch (Exception e) {
            log.error("Gemini chat failed", e);
            return "Sorry, AI is unavailable right now.";
        }
    }

    private String geminiGenerate(String prompt) throws Exception {
        String key = appProperties.getGemini().getApiKey();
        String model = appProperties.getGemini().getModel();
        String url = "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent?key=" + key;
        String escaped = prompt.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
        String payload = "{\"contents\":[{\"parts\":[{\"text\":\"" + escaped + "\"}]}]}";

        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(payload, StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
        if (res.statusCode() >= 400) {
            throw new IllegalStateException("Gemini HTTP " + res.statusCode() + ": " + res.body());
        }
        JsonNode root = objectMapper.readTree(res.body());
        JsonNode text = root.path("candidates").path(0).path("content").path("parts").path(0).path("text");
        return text.asText("");
    }

    @Transactional(readOnly = true)
    public List<ProductDto> frequentlyBoughtTogether(UUID productId) {
        var p = productRepository.findActiveWithCategory(productId).orElse(null);
        if (p == null) {
            return List.of();
        }
        return productRepository.findByActiveTrueAndCategoryId(p.getCategory().getId(), PageRequest.of(0, 8))
                .stream()
                .filter(x -> !x.getId().equals(productId))
                .map(ProductMapper::toDto)
                .toList();
    }

    public List<ProductDto> personalized(List<UUID> recentProductIds) {
        List<ProductDto> out = new ArrayList<>();
        for (UUID id : recentProductIds.stream().distinct().limit(3).toList()) {
            out.addAll(frequentlyBoughtTogether(id));
        }
        return out.stream().distinct().limit(12).toList();
    }
}
