package com.shop.service;

import com.shop.config.AppProperties;
import com.shop.util.HaversineUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Service
@RequiredArgsConstructor
public class DeliveryService {

    private final AppProperties appProperties;

    public double distanceKm(double customerLat, double customerLon) {
        return HaversineUtil.distanceKm(
                appProperties.getShop().getLatitude(),
                appProperties.getShop().getLongitude(),
                customerLat,
                customerLon
        );
    }

    public boolean isWithinRadius(double customerLat, double customerLon) {
        return distanceKm(customerLat, customerLon) <= appProperties.getDelivery().getRadiusKm();
    }

    /** Free delivery above ₹500, else ₹40 */
    public BigDecimal deliveryFee(BigDecimal subtotalAfterDiscount) {
        if (subtotalAfterDiscount.compareTo(BigDecimal.valueOf(500)) >= 0) {
            return BigDecimal.ZERO;
        }
        return BigDecimal.valueOf(40);
    }
}
