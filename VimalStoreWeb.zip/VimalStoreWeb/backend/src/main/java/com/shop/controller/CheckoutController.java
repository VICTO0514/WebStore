package com.shop.controller;

import com.shop.dto.CheckoutDtos;
import com.shop.service.AuthService;
import com.shop.service.OrderService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/checkout")
@RequiredArgsConstructor
public class CheckoutController {

    private final OrderService orderService;
    private final AuthService authService;

    @GetMapping("/preview")
    public ResponseEntity<CheckoutDtos.CheckoutPreview> preview(
            Authentication authentication,
            @RequestParam UUID addressId,
            @RequestParam(required = false) String couponCode
    ) {
        return ResponseEntity.ok(orderService.preview(authService.currentUser(authentication), addressId, couponCode));
    }

    @PostMapping("/place")
    public ResponseEntity<CheckoutDtos.PlaceOrderResponse> place(
            Authentication authentication,
            @Valid @RequestBody CheckoutDtos.PlaceOrderRequest req
    ) {
        return ResponseEntity.ok(orderService.placeOrder(authService.currentUser(authentication), req));
    }
}
