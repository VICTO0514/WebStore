package com.shop.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

public class CartDtos {

    public record CartItemDto(UUID id, ProductDto product, int quantity, BigDecimal lineTotal) {}

    public record CartResponse(List<CartItemDto> items, BigDecimal subtotal) {}

    public record AddItemRequest(@NotNull UUID productId, @Min(1) int quantity) {}

    public record UpdateItemRequest(@Min(1) int quantity) {}
}
