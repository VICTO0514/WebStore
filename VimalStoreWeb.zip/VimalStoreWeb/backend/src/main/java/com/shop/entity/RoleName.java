package com.shop.entity;

public enum RoleName {
    CUSTOMER,
    ADMIN
}
