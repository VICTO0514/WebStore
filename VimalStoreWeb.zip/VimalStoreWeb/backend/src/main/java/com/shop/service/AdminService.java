package com.shop.service;

import com.shop.dto.ProductDto;
import com.shop.entity.OrderStatus;
import com.shop.entity.ProductEntity;
import com.shop.exception.ApiException;
import com.shop.repository.CategoryRepository;
import com.shop.repository.OrderRepository;
import com.shop.repository.ProductRepository;
import com.shop.repository.ReviewRepository;
import com.shop.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AdminService {

    private final OrderRepository orderRepository;
    private final UserRepository userRepository;
    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;
    private final ReviewRepository reviewRepository;

    @Transactional(readOnly = true)
    public Map<String, Object> dashboard() {
        Instant weekAgo = Instant.now().minus(7, ChronoUnit.DAYS);
        Map<String, Object> m = new HashMap<>();
        m.put("ordersTotal", orderRepository.count());
        m.put("customersTotal", userRepository.count());
        m.put("productsTotal", productRepository.count());
        m.put("pendingOrders", orderRepository.countByOrderStatus(OrderStatus.PENDING));
        m.put("revenueWeekEstimate", revenueSince(weekAgo));
        return m;
    }

    private BigDecimal revenueSince(Instant since) {
        return orderRepository.findAll().stream()
                .filter(o -> o.getCreatedAt().isAfter(since))
                .filter(o -> o.getOrderStatus() != OrderStatus.CANCELLED)
                .map(o -> o.getTotal() != null ? o.getTotal() : BigDecimal.ZERO)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(2, RoundingMode.HALF_UP);
    }

    @Transactional
    public ProductDto createProduct(ProductUpsert req) {
        if (req.categoryId() == null) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "categoryId required");
        }
        var cat = categoryRepository.findById(req.categoryId())
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Category not found"));
        ProductEntity p = ProductEntity.builder()
                .name(req.name())
                .description(req.description())
                .category(cat)
                .price(req.price())
                .discountedPrice(req.discountedPrice())
                .unit(req.unit())
                .imageUrl(req.imageUrl())
                .thumbnailUrl(req.thumbnailUrl())
                .mediumUrl(req.mediumUrl())
                .largeUrl(req.largeUrl())
                .featured(Boolean.TRUE.equals(req.featured()))
                .active(req.active() == null || req.active())
                .badge(req.badge())
                .avgRating(BigDecimal.ZERO)
                .reviewCount(0)
                .build();
        productRepository.save(p);
        return ProductMapper.toDto(p);
    }

    @Transactional
    public ProductDto updateProduct(UUID id, ProductUpsert req) {
        ProductEntity p = productRepository.findById(id)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Product not found"));
        if (req.categoryId() != null) {
            p.setCategory(categoryRepository.findById(req.categoryId()).orElseThrow());
        }
        if (req.name() != null) {
            p.setName(req.name());
        }
        if (req.description() != null) {
            p.setDescription(req.description());
        }
        if (req.price() != null) {
            p.setPrice(req.price());
        }
        if (req.discountedPrice() != null) {
            p.setDiscountedPrice(req.discountedPrice());
        }
        if (req.unit() != null) {
            p.setUnit(req.unit());
        }
        if (req.imageUrl() != null) {
            p.setImageUrl(req.imageUrl());
        }
        if (req.thumbnailUrl() != null) {
            p.setThumbnailUrl(req.thumbnailUrl());
        }
        if (req.mediumUrl() != null) {
            p.setMediumUrl(req.mediumUrl());
        }
        if (req.largeUrl() != null) {
            p.setLargeUrl(req.largeUrl());
        }
        if (req.featured() != null) {
            p.setFeatured(req.featured());
        }
        if (req.active() != null) {
            p.setActive(req.active());
        }
        if (req.badge() != null) {
            p.setBadge(req.badge());
        }
        productRepository.save(p);
        return ProductMapper.toDto(p);
    }

    @Transactional(readOnly = true)
    public Page<com.shop.dto.OrderDto> allOrders(int page, int size) {
        return orderRepository.findAllByOrderByCreatedAtDesc(PageRequest.of(page, size)).map(OrderMapper::toDto);
    }

    @Transactional
    public void updateOrderStatus(String orderNumber, OrderStatus status) {
        var o = orderRepository.findByOrderNumber(orderNumber)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Order not found"));
        o.setOrderStatus(status);
        orderRepository.save(o);
    }

    @Transactional
    public void setReviewVisibility(UUID reviewId, boolean visible) {
        var r = reviewRepository.findById(reviewId).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Review not found"));
        r.setVisible(visible);
        r.setModerated(true);
        reviewRepository.save(r);
    }

    public record ProductUpsert(
            String name,
            String description,
            UUID categoryId,
            BigDecimal price,
            BigDecimal discountedPrice,
            String unit,
            String imageUrl,
            String thumbnailUrl,
            String mediumUrl,
            String largeUrl,
            Boolean featured,
            Boolean active,
            String badge
    ) {}
}
