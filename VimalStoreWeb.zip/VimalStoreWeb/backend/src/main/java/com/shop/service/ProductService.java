package com.shop.service;

import com.shop.dto.CategoryDto;
import com.shop.dto.ProductDto;
import com.shop.exception.ApiException;
import com.shop.repository.CategoryRepository;
import com.shop.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;

    @Transactional(readOnly = true)
    public Page<ProductDto> list(String categorySlug, String q, String sort, int page, int size) {
        Sort s = parseSort(sort);
        Pageable pageable = PageRequest.of(page, size, s);
        Page<com.shop.entity.ProductEntity> result;
        if (q != null && !q.isBlank()) {
            result = productRepository.searchActive(q.trim(), categorySlug, pageable);
        } else if (categorySlug != null && !categorySlug.isBlank()) {
            var cat = categoryRepository.findBySlug(categorySlug)
                    .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Category not found"));
            result = productRepository.findByActiveTrueAndCategoryId(cat.getId(), pageable);
        } else {
            result = productRepository.findByActiveTrue(pageable);
        }
        return result.map(ProductMapper::toDto);
    }

    @Transactional(readOnly = true)
    @Cacheable(cacheNames = "products", key = "#id")
    public ProductDto get(UUID id) {
        var p = productRepository.findActiveWithCategory(id)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Product not found"));
        return ProductMapper.toDto(p);
    }

    @Transactional(readOnly = true)
    public Page<ProductDto> featured(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        return productRepository.findByActiveTrueAndFeaturedTrue(pageable).map(ProductMapper::toDto);
    }

    private Sort parseSort(String sort) {
        if (sort == null || sort.isBlank()) {
            return Sort.by("name").ascending();
        }
        return switch (sort.toLowerCase()) {
            case "price_asc" -> Sort.by("price").ascending();
            case "price_desc" -> Sort.by("price").descending();
            case "newest" -> Sort.by("createdAt").descending();
            default -> Sort.by("name").ascending();
        };
    }

    @Transactional(readOnly = true)
    public java.util.List<CategoryDto> categories() {
        return categoryRepository.findByActiveTrueOrderBySortOrderAsc().stream()
                .map(c -> new CategoryDto(c.getId(), c.getName(), c.getSlug(), c.getDescription(), c.getImageUrl(), c.getHeroImageUrl()))
                .toList();
    }
}
