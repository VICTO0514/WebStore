package com.shop.repository;

import com.shop.entity.WishlistEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface WishlistRepository extends JpaRepository<WishlistEntity, UUID> {
    List<WishlistEntity> findByUser_Id(UUID userId);
    Optional<WishlistEntity> findByUser_IdAndProduct_Id(UUID userId, UUID productId);
    void deleteByUser_IdAndProduct_Id(UUID userId, UUID productId);
}
