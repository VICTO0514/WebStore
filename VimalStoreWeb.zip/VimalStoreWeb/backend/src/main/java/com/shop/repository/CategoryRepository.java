package com.shop.repository;

import com.shop.entity.CategoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface CategoryRepository extends JpaRepository<CategoryEntity, UUID> {
    List<CategoryEntity> findByActiveTrueOrderBySortOrderAsc();
    Optional<CategoryEntity> findBySlug(String slug);
}
