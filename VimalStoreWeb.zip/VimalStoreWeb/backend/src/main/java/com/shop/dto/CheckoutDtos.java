package com.shop.dto;

import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.util.UUID;

public class CheckoutDtos {

    public record CheckoutPreview(
            BigDecimal subtotal,
            BigDecimal deliveryFee,
            BigDecimal discount,
            BigDecimal total,
            boolean eligible,
            double distanceKm,
            String couponCode
    ) {}

    public record PlaceOrderRequest(
            @NotNull UUID addressId,
            String paymentMethod,
            String couponCode,
            String notes
    ) {}

    public record PlaceOrderResponse(
            UUID orderId,
            String orderNumber,
            String paymentMethod,
            BigDecimal total,
            String razorpayOrderId,
            String razorpayKeyId
    ) {}

    public record RazorpayVerifyRequest(
            @NotNull String razorpayOrderId,
            @NotNull String razorpayPaymentId,
            @NotNull String razorpaySignature
    ) {}
}
