package com.shop.service;

import com.shop.config.AppProperties;
import com.shop.repository.SettingRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class SettingsService {

    private final SettingRepository settingRepository;
    private final AppProperties appProperties;

    @Transactional(readOnly = true)
    public Map<String, String> publicSettings() {
        Map<String, String> map = new HashMap<>();
        map.put("shop.name", appProperties.getShop().getName());
        map.put("shop.phone", appProperties.getShop().getPhone());
        map.put("shop.email", appProperties.getShop().getEmail());
        map.put("shop.address", appProperties.getShop().getAddress());
        map.put("shop.latitude", String.valueOf(appProperties.getShop().getLatitude()));
        map.put("shop.longitude", String.valueOf(appProperties.getShop().getLongitude()));
        map.put("delivery.radius_km", String.valueOf(appProperties.getDelivery().getRadiusKm()));

        settingRepository.findAll().forEach(s -> map.putIfAbsent(s.getKey(), s.getValue()));
        return map;
    }
}
