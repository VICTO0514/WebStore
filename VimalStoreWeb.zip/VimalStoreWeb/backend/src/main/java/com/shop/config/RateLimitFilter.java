package com.shop.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Simple sliding-window rate limit per IP for /api/** (excluding OPTIONS).
 */
@Component
@Order(1)
@RequiredArgsConstructor
public class RateLimitFilter extends OncePerRequestFilter {

    private final AppProperties appProperties;

    private final Map<String, Window> windows = new ConcurrentHashMap<>();

    private static final class Window {
        long windowStart = Instant.now().toEpochMilli();
        int count;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        if (!request.getRequestURI().startsWith("/api/") || "OPTIONS".equalsIgnoreCase(request.getMethod())) {
            filterChain.doFilter(request, response);
            return;
        }
        String ip = request.getRemoteAddr();
        long now = Instant.now().toEpochMilli();
        int limit = appProperties.getRateLimit().getRequestsPerMinute();
        Window w = windows.computeIfAbsent(ip, k -> new Window());
        synchronized (w) {
            if (now - w.windowStart > 60_000) {
                w.windowStart = now;
                w.count = 0;
            }
            w.count++;
            if (w.count > limit) {
                response.setStatus(HttpStatus.TOO_MANY_REQUESTS.value());
                response.getWriter().write("{\"error\":\"Rate limit exceeded\"}");
                return;
            }
        }
        filterChain.doFilter(request, response);
    }
}
