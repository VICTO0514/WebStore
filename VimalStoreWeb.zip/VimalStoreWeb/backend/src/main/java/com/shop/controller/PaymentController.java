package com.shop.controller;

import com.shop.dto.CheckoutDtos;
import com.shop.service.AuthService;
import com.shop.service.OrderService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final OrderService orderService;
    private final AuthService authService;

    @PostMapping("/razorpay/verify")
    public ResponseEntity<Void> verify(
            Authentication authentication,
            @Valid @RequestBody CheckoutDtos.RazorpayVerifyRequest req
    ) {
        orderService.verifyRazorpay(authService.currentUser(authentication), req);
        return ResponseEntity.ok().build();
    }
}
