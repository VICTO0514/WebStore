package com.shop.controller;

import com.shop.dto.ReviewDtos;
import com.shop.service.AuthService;
import com.shop.service.ReviewService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/reviews")
@RequiredArgsConstructor
public class ReviewController {

    private final ReviewService reviewService;
    private final AuthService authService;

    @GetMapping("/product/{productId}")
    public ResponseEntity<Page<ReviewDtos.ReviewResponse>> forProduct(
            @PathVariable UUID productId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        return ResponseEntity.ok(reviewService.forProduct(productId, page, size));
    }

    @PostMapping
    public ResponseEntity<ReviewDtos.ReviewResponse> create(
            Authentication authentication,
            @Valid @RequestBody ReviewDtos.CreateReviewRequest req
    ) {
        return ResponseEntity.ok(reviewService.create(authService.currentUser(authentication), req));
    }
}
