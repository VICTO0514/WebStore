package com.shop.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

import java.time.Instant;
import java.util.UUID;

public class ReviewDtos {

    public record ReviewResponse(
            UUID id,
            int rating,
            String title,
            String comment,
            String authorName,
            Instant createdAt
    ) {}

    public record CreateReviewRequest(
            @NotNull UUID productId,
            UUID orderId,
            @Min(1) @Max(5) int rating,
            String title,
            String comment
    ) {}
}
