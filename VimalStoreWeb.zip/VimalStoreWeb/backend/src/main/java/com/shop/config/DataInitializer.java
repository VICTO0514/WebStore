package com.shop.config;

import com.shop.entity.RoleName;
import com.shop.entity.UserEntity;
import com.shop.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@RequiredArgsConstructor
@Slf4j
public class DataInitializer {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Bean
    CommandLineRunner seedAdmin() {
        return args -> {
            String email = "admin@shop.com";
            if (!userRepository.existsByEmail(email)) {
                UserEntity admin = UserEntity.builder()
                        .email(email)
                        .passwordHash(passwordEncoder.encode("Admin@123"))
                        .fullName("Store Admin")
                        .phone("+919000000000")
                        .role(RoleName.ADMIN)
                        .preferredLanguage("en")
                        .build();
                userRepository.save(admin);
                log.info("Seeded default admin user {}", email);
            }
        };
    }
}
