package com.shop.service;

import com.shop.entity.ChatMessageEntity;
import com.shop.entity.UserEntity;
import com.shop.repository.ChatMessageRepository;
import com.shop.repository.UserRepository;
import com.shop.security.SecurityUser;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ChatSessionService {

    private final ChatMessageRepository chatMessageRepository;
    private final AiIntegrationService aiIntegrationService;
    private final UserRepository userRepository;

    @Transactional
    public String reply(SecurityUser user, String sessionId, String message) {
        UserEntity u = userRepository.findById(user.getId()).orElseThrow();
        chatMessageRepository.save(ChatMessageEntity.builder()
                .user(u)
                .sessionId(sessionId)
                .role("user")
                .content(message)
                .build());

        List<String> tail = chatMessageRepository.findBySessionIdOrderByCreatedAtAsc(sessionId).stream()
                .map(ChatMessageEntity::getContent)
                .limit(10)
                .toList();

        String answer = aiIntegrationService.chatReply(message, tail);
        chatMessageRepository.save(ChatMessageEntity.builder()
                .user(u)
                .sessionId(sessionId)
                .role("assistant")
                .content(answer)
                .build());
        return answer;
    }

    public String anonymousReply(String sessionId, String message) {
        chatMessageRepository.save(ChatMessageEntity.builder()
                .sessionId(sessionId)
                .role("user")
                .content(message)
                .build());
        List<String> tail = chatMessageRepository.findBySessionIdOrderByCreatedAtAsc(sessionId).stream()
                .map(ChatMessageEntity::getContent)
                .limit(10)
                .toList();
        String answer = aiIntegrationService.chatReply(message, tail);
        chatMessageRepository.save(ChatMessageEntity.builder()
                .sessionId(sessionId)
                .role("assistant")
                .content(answer)
                .build());
        return answer;
    }

    /** Guest sessions use random UUID client-side */
    public String newSessionId() {
        return UUID.randomUUID().toString();
    }
}
