package com.shop.repository;

import com.shop.entity.ReviewEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface ReviewRepository extends JpaRepository<ReviewEntity, UUID> {
    Page<ReviewEntity> findByProduct_IdAndVisibleTrueOrderByCreatedAtDesc(UUID productId, Pageable pageable);

    Optional<ReviewEntity> findByProduct_IdAndUser_Id(UUID productId, UUID userId);
}
