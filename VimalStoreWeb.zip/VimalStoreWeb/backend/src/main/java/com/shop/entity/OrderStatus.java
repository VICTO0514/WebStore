package com.shop.entity;

public enum OrderStatus {
    PENDING,
    CONFIRMED,
    PACKED,
    OUT_FOR_DELIVERY,
    DELIVERED,
    CANCELLED
}
