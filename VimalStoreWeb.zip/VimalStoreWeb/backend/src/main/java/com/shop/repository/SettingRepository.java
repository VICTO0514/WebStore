package com.shop.repository;

import com.shop.entity.SettingEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface SettingRepository extends JpaRepository<SettingEntity, UUID> {
    Optional<SettingEntity> findByKey(String key);
}
