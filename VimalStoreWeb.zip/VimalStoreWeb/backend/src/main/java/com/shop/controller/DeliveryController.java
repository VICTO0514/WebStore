package com.shop.controller;

import com.shop.config.AppProperties;
import com.shop.service.DeliveryService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/v1/delivery")
@RequiredArgsConstructor
public class DeliveryController {

    private final DeliveryService deliveryService;
    private final AppProperties appProperties;

    @GetMapping("/check")
    public ResponseEntity<Map<String, Object>> check(
            @RequestParam double lat,
            @RequestParam double lng
    ) {
        double km = deliveryService.distanceKm(lat, lng);
        boolean ok = deliveryService.isWithinRadius(lat, lng);
        return ResponseEntity.ok(Map.of(
                "distanceKm", km,
                "eligible", ok,
                "maxRadiusKm", appProperties.getDelivery().getRadiusKm()
        ));
    }
}
