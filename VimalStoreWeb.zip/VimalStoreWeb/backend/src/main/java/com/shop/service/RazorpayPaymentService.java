package com.shop.service;

import com.shop.config.AppProperties;
import com.shop.exception.ApiException;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import com.razorpay.Utils;
import lombok.RequiredArgsConstructor;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Service
@RequiredArgsConstructor
public class RazorpayPaymentService {

    private final AppProperties appProperties;

    public boolean configured() {
        String id = appProperties.getRazorpay().getKeyId();
        String sec = appProperties.getRazorpay().getKeySecret();
        return id != null && !id.isBlank() && sec != null && !sec.isBlank();
    }

    public RazorpayOrderResult createOrder(BigDecimal amountInr, String receipt) {
        if (!configured()) {
            throw new ApiException(HttpStatus.SERVICE_UNAVAILABLE, "Razorpay not configured");
        }
        try {
            RazorpayClient client = new RazorpayClient(
                    appProperties.getRazorpay().getKeyId(),
                    appProperties.getRazorpay().getKeySecret()
            );
            JSONObject opts = new JSONObject();
            int paise = amountInr.multiply(BigDecimal.valueOf(100)).setScale(0, RoundingMode.HALF_UP).intValue();
            opts.put("amount", paise);
            opts.put("currency", "INR");
            opts.put("receipt", receipt);
            Order order = client.orders.create(opts);
            return new RazorpayOrderResult(order.get("id"), appProperties.getRazorpay().getKeyId());
        } catch (RazorpayException e) {
            throw new ApiException(HttpStatus.BAD_GATEWAY, "Razorpay error: " + e.getMessage());
        }
    }

    public boolean verifySignature(String orderId, String paymentId, String signature) {
        if (!configured()) {
            return false;
        }
        try {
            JSONObject attrs = new JSONObject();
            attrs.put("razorpay_order_id", orderId);
            attrs.put("razorpay_payment_id", paymentId);
            attrs.put("razorpay_signature", signature);
            return Utils.verifyPaymentSignature(attrs, appProperties.getRazorpay().getKeySecret());
        } catch (RazorpayException e) {
            return false;
        }
    }

    public record RazorpayOrderResult(String razorpayOrderId, String keyId) {}
}
