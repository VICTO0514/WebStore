# Vimal Store — AI-powered grocery delivery

Production-oriented monorepo for a **local grocery** with **10 km delivery**, **Spring Boot** API, **Supabase PostgreSQL**, **vanilla JS** storefront (GSAP, Three.js, Swiper, AOS, Leaflet), **Gemini** AI hooks, **Razorpay**, **Twilio SMS**, and an **admin dashboard**.

## Repository layout

```
├── frontend/           # Static site (Vercel): HTML/CSS/JS
├── backend/            # Spring Boot 3 · Java 21 · Maven
├── supabase/           # PostgreSQL schema + seed SQL
├── docs/API.md         # REST reference
└── postman/            # Postman collection
```

## Quick start (local)

### 1. Database (Supabase)

1. Create a Supabase project → **SQL Editor** → run `supabase/schema.sql`, then `supabase/seed.sql`.
2. Copy the **JDBC** connection string (Session pooler or direct IPv4 add-on per Supabase docs).
3. **Storage (optional):** create bucket `product-images` (public read) if you upload WebP variants from an offline script; seed data already uses royalty-free Unsplash URLs.

### 2. Backend

```bash
cd backend
cp .env.example .env   # export variables or use IDE env
# Set DATABASE_URL / DATABASE_USER / DATABASE_PASSWORD / JWT_SECRET (long random string)
mvn spring-boot:run
```

API listens on `http://localhost:8080`. On first boot, an **admin** user is created if missing:

- **Email:** `admin@shop.com`
- **Password:** `Admin@123`

Override shop coordinates and branding via env (`SHOP_LATITUDE`, `SHOP_LONGITUDE`, `SHOP_NAME`, …) — see `backend/src/main/resources/application.yml`.

### 3. Frontend

Serve static files (Live Server, `npx serve frontend`, or open via IDE). Configure API URL:

- Query param once: `index.html?api=http://localhost:8080`
- Or `localStorage.setItem('API_BASE','http://localhost:8080')`
- Or embed `window.__API_BASE__ = 'https://api.yourdomain.com'` before scripts.

CORS must include your frontend origin (`CORS_ORIGINS`).

## Architecture (concise)

- **Auth:** JWT (HS256), BCrypt passwords, role `CUSTOMER` / `ADMIN`.
- **Delivery:** Haversine distance vs configurable shop lat/lng; orders rejected beyond `DELIVERY_RADIUS_KM` (default **10**).
- **Payments:** COD always available; Razorpay **order** created server-side, Checkout handled in browser, `/payments/razorpay/verify` validates signature.
- **Notifications:** Twilio SMS to `OWNER_NOTIFY_PHONE` on new order (skipped gracefully if Twilio env vars absent — logged instead).
- **AI:** Optional **Gemini** (`GEMINI_API_KEY`) for NL query rewriting + chat; heuristic sentiment for reviews when Gemini absent.
- **Rate limiting:** Simple per-IP limit on `/api/**` (see `RateLimitFilter`).

## Deployment

| Layer | Suggested |
|-------|-----------|
| Frontend | **Vercel** — project root `frontend`, output static files; set env in HTML bootstrap if needed |
| Backend | **Render** or **Railway** — Java 21, `mvn -DskipTests package`, `java -jar target/vimal-store-api-1.0.0.jar` |
| Database | **Supabase Postgres** |
| Secrets | JWT secret, Razorpay keys, Twilio, Gemini |

Render/Railway: set env vars from `backend/.env.example`. Health check path: `GET /api/v1/settings/public`.

## Testing

```bash
cd backend && mvn test
```

Includes `HaversineUtilTest`. Extend with `@WebMvcTest` / Testcontainers as needed.

## SEO & analytics

- `frontend/robots.txt`, `frontend/sitemap.xml` — replace `YOUR_VERCEL_DOMAIN`.
- Google Analytics: set `window.__GA_ID__ = 'G-XXXX'` before scripts on pages you care about.

## Image pipeline

Seed products ship with **Unsplash** URLs (`?w=` size hints). For strict WebP + Supabase Storage workflows, run your own uploader (CLI or admin tool) and replace `image_url` / `thumbnail_url` / `medium_url` / `large_url` in `products`.

## Security checklist (production)

- Rotate **JWT_SECRET** (≥ 256-bit entropy).
- Change default **admin** password; consider disabling open registration or adding CAPTCHA.
- Lock Twilio / Razorpay keys to server env only.
- Enable HTTPS everywhere; tighten `CORS_ORIGINS`.

## License / images

Product imagery in seed data is from **Unsplash** (license compatible with typical Unsplash terms). Replace with your own assets for branded packs.

---

For endpoint details see **`docs/API.md`**. Postman: **`postman/Vimal-Store.postman_collection.json`**.
